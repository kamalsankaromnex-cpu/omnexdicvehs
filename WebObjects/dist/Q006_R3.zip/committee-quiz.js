/**
 * committee-quiz.js — Shared Interaction Controller for Q006 Scenarios
 * Used by Q006_R1, Q006_R2, and Q006_R3
 */
(function (global) {
  'use strict';

  function initCommitteeQuiz(roundKey) {
    var data = global.DICV_COMMITTEE_DATA && global.DICV_COMMITTEE_DATA[roundKey];
    if (!data) {
      console.error('Missing committee data for round:', roundKey);
      return;
    }

    var state = {
      selectedOptionId: null,
      status: 'READY', // 'READY', 'SUBMITTED', 'REVEALED'
      isCorrect: false
    };

    // DOM Elements
    var issueBadge = document.getElementById('issue-badge');
    var progressTracker = document.getElementById('progress-tracker');
    var scenarioImg = document.getElementById('scenario-image');
    var scenarioText = document.getElementById('scenario-text');
    var questionText = document.getElementById('question-text');
    var optionsGrid = document.getElementById('options-grid');
    var btnSubmit = document.getElementById('btn-submit');

    // Populate Static Content
    if (issueBadge) issueBadge.textContent = data.issueTitle;
    if (scenarioImg) {
      scenarioImg.src = data.illustration;
      scenarioImg.alt = data.scenarioName;
    }
    if (scenarioText) scenarioText.textContent = data.scenarioText;
    if (questionText) questionText.textContent = data.questionText;

    // Render Progress Tracker (3 Steps matching reference image)
    if (progressTracker) {
      progressTracker.innerHTML = '';
      for (var i = 1; i <= data.totalRounds; i++) {
        var node = document.createElement('div');
        node.className = 'step-node';
        if (i < data.roundIndex) {
          node.classList.add('is-completed');
        } else if (i === data.roundIndex) {
          node.classList.add('is-active');
        }

        var circle = document.createElement('div');
        circle.className = 'step-circle';
        circle.textContent = i;
        node.appendChild(circle);

        if (i < data.totalRounds) {
          var line = document.createElement('div');
          line.className = 'step-line';
          node.appendChild(line);
        }

        progressTracker.appendChild(node);
      }
    }

    // Render Committee Option Cards
    if (optionsGrid) {
      optionsGrid.innerHTML = '';
      data.options.forEach(function (opt) {
        var card = document.createElement('div');
        card.className = 'committee-card';
        card.id = 'card-' + opt.id;
        card.setAttribute('data-option-id', opt.id);
        card.setAttribute('role', 'radio');
        card.setAttribute('aria-checked', 'false');
        card.setAttribute('tabindex', '0');

        card.innerHTML = 
          '<span class="card-status-badge"></span>' +
          '<div class="radio-control" aria-hidden="true">' +
            '<div class="radio-dot"></div>' +
          '</div>' +
          '<img class="committee-icon" src="' + opt.icon + '" alt="" aria-hidden="true">' +
          '<div class="committee-label">' + opt.label + '</div>';

        // Click Handler
        card.addEventListener('click', function () {
          if (state.status !== 'READY') return;
          selectOption(opt.id);
        });

        // Keyboard Handler
        card.addEventListener('keydown', function (e) {
          if (state.status !== 'READY') return;
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            selectOption(opt.id);
          }
        });

        optionsGrid.appendChild(card);
      });
    }

    // Selection Function
    function selectOption(optionId) {
      state.selectedOptionId = optionId;
      var cards = Array.from(document.querySelectorAll('.committee-card'));
      cards.forEach(function (c) {
        var cid = c.getAttribute('data-option-id');
        if (cid === optionId) {
          c.classList.add('is-selected');
          c.setAttribute('aria-checked', 'true');
        } else {
          c.classList.remove('is-selected');
          c.setAttribute('aria-checked', 'false');
        }
      });

      if (btnSubmit) {
        btnSubmit.disabled = (state.selectedOptionId === null || state.status !== 'READY');
      }
    }

    // Storyline Communication Bridge
    var bridge = new DICVStorylineBridge({
      quizId: data.quizId,
      autoPoll: true,
      pollIntervalMs: 150,
      storylineVariables: data.storylineVariables,
      onRevealAnswers: function () {
        revealReviewMode();
      },
      onResetState: function () {
        resetQuiz();
      }
    });

    // Revisit Slide State Restoration
    if (bridge.state && bridge.state.submitted) {
      state.status = 'SUBMITTED';
      state.isCorrect = !!bridge.state.isCorrect;
      if (bridge.state.submittedSelection) {
        var prevId = typeof bridge.state.submittedSelection === 'string'
          ? bridge.state.submittedSelection
          : bridge.state.submittedSelection.optionId;
        if (prevId) {
          selectOption(prevId);
        }
      }
      lockInteraction();
      if (bridge.state.revealed) {
        revealReviewMode();
      }
    }

    // Lock Interaction
    function lockInteraction() {
      var cards = Array.from(document.querySelectorAll('.committee-card'));
      cards.forEach(function (c) {
        c.classList.add('is-locked');
        c.setAttribute('tabindex', '-1');
      });
      if (btnSubmit) {
        btnSubmit.disabled = true;
      }
    }

    // Submit Handler
    if (btnSubmit) {
      btnSubmit.addEventListener('click', function () {
        if (btnSubmit.disabled || state.status !== 'READY' || !state.selectedOptionId) return;

        state.status = 'SUBMITTED';
        var isCorrect = (state.selectedOptionId === data.correctAnswerId);
        state.isCorrect = isCorrect;

        var selectedOpt = data.options.find(function (o) { return o.id === state.selectedOptionId; });
        var answerLabel = selectedOpt ? selectedOpt.label.replace(/\n/g, ' ') : state.selectedOptionId;

        lockInteraction();

        // Submit to Storyline Bridge
        bridge.submit(answerLabel, isCorrect);
      });
    }

    // Review Mode (Triggered by Storyline Reveal)
    function revealReviewMode() {
      state.status = 'REVEALED';
      lockInteraction();

      var cards = Array.from(document.querySelectorAll('.committee-card'));
      cards.forEach(function (c) {
        var cid = c.getAttribute('data-option-id');
        var badge = c.querySelector('.card-status-badge');

        if (cid === data.correctAnswerId) {
          c.classList.add('is-review-correct');
          if (badge) badge.textContent = '✓ Correct';
        } else if (cid === state.selectedOptionId) {
          c.classList.add('is-review-incorrect');
          if (badge) badge.textContent = '✕ Incorrect';
        }
      });
    }

    // Reset Quiz
    function resetQuiz() {
      state.selectedOptionId = null;
      state.status = 'READY';
      state.isCorrect = false;

      var cards = Array.from(document.querySelectorAll('.committee-card'));
      cards.forEach(function (c) {
        c.classList.remove('is-selected', 'is-locked', 'is-review-correct', 'is-review-incorrect');
        c.setAttribute('aria-checked', 'false');
        c.setAttribute('tabindex', '0');
        var badge = c.querySelector('.card-status-badge');
        if (badge) {
          badge.textContent = '';
          badge.style.display = 'none';
        }
      });

      if (btnSubmit) btnSubmit.disabled = true;
    }

    // Automated QA & Headless Capture URL Hooks: ?state=selected, ?state=review, ?no_anim=1
    try {
      var href = window.location.href;
      var searchMatch = href.match(/[?&]state=([^&]+)/);
      var hashMatch = href.match(/#([^?&]+)/);
      var qaState = searchMatch ? searchMatch[1] : (hashMatch ? hashMatch[1] : null);

      if (href.indexOf('no_anim=1') !== -1 || qaState) {
        document.documentElement.classList.add('no-animation');
      }

      if (qaState === 'selected') {
        selectOption(data.correctAnswerId);
      } else if (qaState === 'review') {
        var incOpt = data.options.find(function (o) { return o.id !== data.correctAnswerId; });
        selectOption(incOpt ? incOpt.id : data.correctAnswerId);
        state.status = 'SUBMITTED';
        revealReviewMode();
      }
    } catch (e) {
      console.warn('QA hook init failed:', e);
    }
  }

  global.initCommitteeQuiz = initCommitteeQuiz;
})(window);
