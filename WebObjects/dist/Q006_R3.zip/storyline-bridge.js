/**
 * DICV Interactive — Articulate Storyline 360 Bridge Protocol
 * Module: WebObjects/shared/storyline/storyline-bridge.js
 *
 * Implements the bidirectional contract between the HTML Web Object iframe
 * and Articulate Storyline 360 (via GetPlayer() API or postMessage).
 */

(function (root, factory) {
  if (typeof define === 'function' && define.amd) {
    define([], factory);
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.DICVStorylineBridge = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var PROTOCOL_VERSION = '1.0.0';

  function findStorylinePlayer() {
    // 1. Try window.parent
    try {
      if (window.parent && typeof window.parent.GetPlayer === 'function') {
        return window.parent.GetPlayer();
      }
    } catch (e) {}

    // 2. Try window.top
    try {
      if (window.top && typeof window.top.GetPlayer === 'function') {
        return window.top.GetPlayer();
      }
    } catch (e) {}

    // 3. Try traversing parent hierarchy
    try {
      var curr = window;
      while (curr.parent && curr.parent !== curr) {
        curr = curr.parent;
        if (typeof curr.GetPlayer === 'function') {
          return curr.GetPlayer();
        }
      }
    } catch (e) {}

    // 4. Try window.opener (for popout Web Objects)
    try {
      if (window.opener && typeof window.opener.GetPlayer === 'function') {
        return window.opener.GetPlayer();
      }
    } catch (e) {}

    return null;
  }

  function StorylineBridge(config) {
    this.quizId = config.quizId || 'UNKNOWN_QUIZ';
    this.variableMap = config.storylineVariables || {};
    this.onStateReceived = config.onStateReceived || function () {};
    this.onRevealAnswers = config.onRevealAnswers || function () {};
    this.onResetAttempt = config.onResetAttempt || function () {};
    this.allowedOrigins = config.allowedOrigins || ['*']; // Configurable for production

    this.state = {
      attemptId: 'attempt-1',
      draftSelection: null,
      submitted: false,
      submittedSelection: null,
      result: null,
      revealed: false
    };

    this.player = null;
    this.isStorylineAvailable = false;
    this._pollingInterval = null;
    this.init();
  }

  StorylineBridge.prototype.getPlayer = function () {
    if (!this.player) {
      this.player = findStorylinePlayer();
      if (this.player) {
        this.isStorylineAvailable = true;
      }
    }
    return this.player;
  };

  StorylineBridge.prototype.startPolling = function () {
    if (this._pollingInterval) return;
    var self = this;
    var revealedVar = this.variableMap.revealed || (this.quizId + '_Revealed');

    this._pollingInterval = setInterval(function () {
      try {
        var p = self.getPlayer();
        if (!p || typeof p.GetVar !== 'function') return;

        var val1 = p.GetVar(revealedVar);
        var val2 = p.GetVar(revealedVar.toLowerCase());
        var isRev = (val1 === true || val1 === 'true' || val1 === 1 || val2 === true || val2 === 'true' || val2 === 1);
        if (isRev && !self.state.revealed) {
          self.state.revealed = true;
          console.log('[DICV StorylineBridge] Poller detected ' + revealedVar + ' = true. Triggering review mode.');
          self.onRevealAnswers(self.state.submittedSelection);
        }
      } catch (e) {}
    }, 150);
  };

  StorylineBridge.prototype.stopPolling = function () {
    if (this._pollingInterval) {
      clearInterval(this._pollingInterval);
      this._pollingInterval = null;
    }
  };

  StorylineBridge.prototype.init = function () {
    var self = this;

    // Check if Storyline GetPlayer() is available directly
    this.getPlayer();

    // Set up postMessage listener
    window.addEventListener('message', function (event) {
      self.handleIncomingMessage(event);
    });

    // Notify parent that Web Object is loaded and ready
    this.sendToParent('QUIZ_READY', {
      quizId: this.quizId,
      protocolVersion: PROTOCOL_VERSION,
      timestamp: Date.now(),
      nonce: this.generateId()
    });

    // If direct player is available, read state immediately
    if (this.player) {
      this.syncFromDirectPlayer();
    }

    // Always start active polling to catch dynamic Storyline variable updates (e.g. Q002_Revealed)
    this.startPolling();
  };

  StorylineBridge.prototype.generateId = function () {
    return 'evt_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
  };

  StorylineBridge.prototype.syncFromDirectPlayer = function () {
    try {
      var submittedVar = this.variableMap.submitted || (this.quizId + '_Done');
      var answersVar = this.variableMap.answers || (this.quizId + '_Answers');
      var revealedVar = this.variableMap.revealed || (this.quizId + '_Revealed');

      var isSubmitted = Boolean(this.player.GetVar(submittedVar));
      var savedAnswers = this.player.GetVar(answersVar);
      var isRevealed = Boolean(this.player.GetVar(revealedVar));

      var parsedAnswers = null;
      if (savedAnswers) {
        try {
          parsedAnswers = JSON.parse(savedAnswers);
        } catch (e) {
          parsedAnswers = savedAnswers;
        }
      }

      this.state.submitted = isSubmitted;
      this.state.submittedSelection = parsedAnswers;
      this.state.revealed = isRevealed;

      this.onStateReceived(this.state);

      if (isRevealed) {
        this.onRevealAnswers(parsedAnswers);
      }
    } catch (e) {
      console.warn('[DICV StorylineBridge] Direct GetVar read failed:', e);
    }
  };

  StorylineBridge.prototype.handleIncomingMessage = function (event) {
    var data = event.data;
    if (!data || typeof data !== 'object') {
      return;
    }
    if (data.quizId && data.quizId !== this.quizId) {
      return;
    }

    switch (data.type) {
      case 'QUIZ_STATE':
        this.state = Object.assign(this.state, data.payload || {});
        this.onStateReceived(this.state);
        if (this.state.revealed) {
          this.onRevealAnswers(this.state.submittedSelection);
        }
        break;

      case 'QUIZ_SUBMIT_ACK':
        this.state.submitted = true;
        this.state.submittedSelection = data.payload.answers;
        this.state.result = data.payload.result;
        break;

      case 'QUIZ_REVEAL_ANSWERS':
        this.state.revealed = true;
        this.onRevealAnswers(this.state.submittedSelection);
        break;

      case 'QUIZ_RESET_ATTEMPT':
        this.state = {
          attemptId: data.payload.attemptId || this.generateId(),
          draftSelection: null,
          submitted: false,
          submittedSelection: null,
          result: null,
          revealed: false
        };
        this.onResetAttempt();
        break;

      default:
        break;
    }
  };

  StorylineBridge.prototype.sendToParent = function (type, payload) {
    var message = {
      protocol: 'DICV_STORYLINE_INTERACTIVE',
      version: PROTOCOL_VERSION,
      quizId: this.quizId,
      type: type,
      payload: payload
    };

    try {
      if (window.parent && window.parent !== window) {
        window.parent.postMessage(message, '*');
      }
    } catch (e) {}

    try {
      if (window.top && window.top !== window && window.top !== window.parent) {
        window.top.postMessage(message, '*');
      }
    } catch (e) {}
  };

  StorylineBridge.prototype.notifyDraftChange = function (selection) {
    this.state.draftSelection = selection;
    this.sendToParent('QUIZ_DRAFT_CHANGE', {
      selection: selection,
      timestamp: Date.now()
    });
  };

  StorylineBridge.prototype.submit = function (selection, isCorrect) {
    if (this.state.submitted) {
      console.warn('[DICV StorylineBridge] Submission already committed for this attempt.');
      return false;
    }

    var eventId = this.generateId();
    this.state.submitted = true;
    this.state.submittedSelection = selection;
    this.state.result = isCorrect;

    // Direct Storyline Variable Updates: dynamically query player at submit time
    var p = this.getPlayer();
    var playerFound = false;

    if (p && typeof p.SetVar === 'function') {
      try {
        playerFound = true;
        var submittedVar = this.variableMap.submitted || (this.quizId + '_Done');
        var answersVar = this.variableMap.answers || (this.quizId + '_Answers');
        var correctVar = this.variableMap.correct || (this.quizId + '_Correct');

        var jsonAnswers = typeof selection === 'string' ? selection : JSON.stringify(selection);

        // 1. Set answers string variable
        try { p.SetVar(answersVar, jsonAnswers); } catch (e) {}
        try { p.SetVar(this.quizId + '_answers', jsonAnswers); } catch (e) {}

        // 2. Set correct boolean variable BEFORE trigger fires
        if (typeof isCorrect !== 'undefined') {
          var boolCorrect = Boolean(isCorrect);
          try { p.SetVar(correctVar, boolCorrect); } catch (e) {}
          try { p.SetVar(this.quizId + '_correct', boolCorrect); } catch (e) {}
        }

        // 3. Set submitted done variable
        // Check current value: only toggle false->true if it was already true
        var currVal = false;
        try { currVal = p.GetVar(submittedVar); } catch (e) {}

        if (currVal === true || currVal === 'true' || currVal === 1) {
          try { p.SetVar(submittedVar, false); } catch (e) {}
          setTimeout(function () {
            try { p.SetVar(submittedVar, true); } catch (e) {}
            try { p.SetVar(submittedVar.toLowerCase(), true); } catch (e) {}
          }, 35);
        } else {
          // Slight 25ms delay to guarantee Storyline commits correctVar before firing the doneVar trigger
          setTimeout(function () {
            try { p.SetVar(submittedVar, true); } catch (e) {}
            try { p.SetVar(submittedVar.toLowerCase(), true); } catch (e) {}
          }, 25);
        }

        // Ensure poller is actively running to catch Q002_Revealed = true
        this.startPolling();

        console.log('[DICV StorylineBridge] SetVar committed successfully:', {
          quizId: this.quizId,
          answersVar: answersVar,
          correctVar: correctVar,
          correct: isCorrect,
          submittedVar: submittedVar
        });
      } catch (e) {
        console.warn('[DICV StorylineBridge] Direct SetVar failed:', e);
      }
    }

    // Send Authoritative Submit Request to Storyline via postMessage
    this.sendToParent('QUIZ_SUBMIT_REQUEST', {
      eventId: eventId,
      answers: selection,
      isCorrect: isCorrect,
      timestamp: Date.now()
    });

    return playerFound;
  };

  return StorylineBridge;
});
